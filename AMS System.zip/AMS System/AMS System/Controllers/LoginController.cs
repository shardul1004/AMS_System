﻿using AMS_System.Data;
using AMS_System.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace AMS_System.Controllers
{
    public class LoginController : Controller
    {
        private readonly ApplicationDbContext _db;
        private readonly string jwtpaswd;
        private readonly IConfiguration _configuration;
        public LoginController(ApplicationDbContext db, IConfiguration configuration)
        {
            _db = db;
            _configuration = configuration;
            jwtpaswd = _configuration["JWTAuth:PrivateKey"].ToString();
        }
        public IActionResult Index()
        {
            return View();
        }

        private string GenerateJWTToken(string userId)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(jwtpaswd);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Name, userId),
                }),
                Expires = DateTime.UtcNow.AddDays(15),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        public IActionResult Login(Users us)
        {
            if(us.UserName==null || us.Password == null)
            {
                if(us.UserName == null)
                {
                    LogInError.UsernameError = "Username Null";
                }
                if(us.Password == null)
                {
                    LogInError.PasswordError = "Password Null";
                }
            }
            else
            {
                var user = _db.Users.FirstOrDefault(u => u.UserName == us.UserName);

                if(user != null)
                {
                    byte[] savedSalt = Convert.FromBase64String(user.Salt);
                    string savedPasswordHash = user.Password;

                    var pbkfd2 = new Rfc2898DeriveBytes(us.Password, savedSalt, 10000);
                    byte[] hash = pbkfd2.GetBytes(20);
                    byte[] hashBytes = new byte[36];
                    Array.Copy(savedSalt, 0, hashBytes, 0, 16);
                    Array.Copy(hash, 0, hashBytes, 16, 20);
                    string computedPasswordHash = Convert.ToBase64String(hashBytes); 

                    if(computedPasswordHash == savedPasswordHash)
                    {
                        var token = GenerateJWTToken(us.UserName.ToString());

                        Response.Cookies.Append("jwtTOken", token, new CookieOptions
                        {
                            Expires = DateTime.UtcNow.AddDays(15),
                            HttpOnly = true
                        });

                        return RedirectToAction("Index", "DashBoard");
                    }
                }
                else
                {
                    LogInError.UsernameError = "Invalid Credentials";
                }
            }

            return RedirectToAction("Index", "Login");
        }
    }
}
