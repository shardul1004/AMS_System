﻿using AMS_System.Data;
using AMS_System.Filters;
using AMS_System.Models;
using Microsoft.AspNetCore.Mvc;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace AMS_System.Controllers
{
    public class DashBoardController : Controller
    {
        IConfiguration _configuration;
        public string jwtpaswd;
        ApplicationDbContext _db;
        public DashBoardController(ApplicationDbContext db,IConfiguration configuration)
        {
            _configuration = configuration;
            jwtpaswd = _configuration["JWTAuth:PrivateKey"].ToString();
            _db = db;
        }
        [ValidateJWT]
        public IActionResult Index()
        {
            string jwtToken = Request.Cookies["jwtToken"];
            if (!string.IsNullOrEmpty(jwtToken))
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var token = tokenHandler.ReadJwtToken(jwtToken);

                // Ensure username claim exists and has a value
                var usernameClaim = token.Claims.FirstOrDefault(p => p.Type == "unique_name").Value?.ToString();

                if (!string.IsNullOrEmpty(usernameClaim))
                {
                    // Perform database query with the username
                    Users us = _db.Users.FirstOrDefault(u => u.UserName == usernameClaim);

                    if (us != null)
                    {
                        return View(us);
                    }
                }
            }

            // Handle cases where token is missing or user not found
            // For example, redirect to a login page or show an error message
            return RedirectToAction("Index", "Login");
        }
    }
}
