﻿namespace AMS_System.Models
{
    public static class LogInError
    {
        public static Users Users { get; set; } 
        public static string UsernameError { get; set; }
        public static string PasswordError { get; set; }
    }
}
