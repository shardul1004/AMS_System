﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Diagnostics;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Text;

namespace AMS_System.Filters
{
    public class ValidateJWT: ActionFilterAttribute
    {
        private readonly string jwtpaswd;
        public ValidateJWT()
        {
            jwtpaswd = "SomeRandomPasswordWithAlphaNumericCharacterLike@#$AlsoNumericData5896ToMakeItLongAndStrong";
        }
        public override async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(jwtpaswd);
            var token = context.HttpContext.Request.Cookies["jwtToken"];
            try
            {
                tokenHandler.ValidateToken(token, new Microsoft.IdentityModel.Tokens.TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    ValidateLifetime = true,
                }, out SecurityToken validateToken);
                await next();
            }
            catch
            {
                context.Result = new RedirectToRouteResult(
                    new RouteValueDictionary
                    {
                        {"controller", "Login" },
                        {"Action", "Index" }
                    }
                    );
            }
        }
    }
}
